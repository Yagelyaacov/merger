#!/usr/bin/env python3
"""Local Git cherry-pick service for merger.html (Python standard library only)."""
import argparse
import base64
import copy
import hmac
import json
import os
from pathlib import Path
import re
import secrets
import sys
import subprocess
import tempfile
import threading
from http.cookies import SimpleCookie
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.error import HTTPError
from urllib.parse import parse_qs, urlsplit
from urllib.request import Request, build_opener, HTTPRedirectHandler
import webbrowser


def git_command():
    """Use the app's bundled Git on Windows; source installs retain system Git."""
    bundled = Path(__file__).resolve().parent / 'git' / 'cmd' / 'git.exe'
    return [str(bundled) if os.name == 'nt' and bundled.is_file() else 'git']


def process_options():
    return {'creationflags': subprocess.CREATE_NO_WINDOW} if os.name == 'nt' else {}


def default_work_dir():
    if os.name == 'nt':
        return str(Path(os.environ.get('LOCALAPPDATA', Path.home() / 'AppData' / 'Local')) / 'ISCARMerger' / 'jobs')
    return '~/.local/share/iscar-merger'


class GitError(Exception):
    pass


def describe_conflicts(repo):
    """Read the index and Git objects only; never resolve, stage, or continue a pick."""
    repo = Path(repo).expanduser().resolve()
    def read(*args):
        env = {k: v for k, v in os.environ.items() if not k.startswith('GIT_')}
        env.update(GIT_CONFIG_GLOBAL=os.devnull, GIT_CONFIG_NOSYSTEM='1', GIT_OPTIONAL_LOCKS='0')
        result = subprocess.run(git_command() + ['--literal-pathspecs', '-C', str(repo), *args],
                                env=env, capture_output=True, timeout=60, **process_options())
        if result.returncode:
            raise GitError(result.stderr.decode('utf-8', errors='replace').strip())
        return result.stdout

    def text(*args):
        return read(*args).decode('utf-8', errors='replace').strip()

    sha = text('rev-parse', '--verify', 'CHERRY_PICK_HEAD')
    parents = text('rev-list', '--parents', '-n', '1', sha).split()[1:]
    entries = {}
    for record in read('ls-files', '--unmerged', '-z').split(b'\0'):
        if not record:
            continue
        meta, raw_path = record.split(b'\t', 1)
        mode, blob, stage = meta.decode().split()
        path = os.fsdecode(raw_path)
        entries.setdefault(path, {})[int(stage)] = (mode, blob)
    if not entries:
        raise GitError('No unmerged paths remain. Review staged changes before continuing the cherry-pick.')
    guidance = [
        'Compare the incoming patch with the release version. The release version includes earlier successful picks.',
        'If the patch edits code absent from the release, investigate earlier source changes before deciding whether to include them or adapt the fix.',
        'Edit only the conflicting sections to preserve the intended release behavior. Remove conflict markers and check syntax and relevant application behavior.',
        'Do not accept an entire source file just to remove a conflict; that can import unselected changes.',
        'After resolving, stage each resolved path with git add -- PATH (or git rm -- PATH for an intended deletion), then run git cherry-pick --continue.',
        'The browser does not resume a manually resolved job. Apply any remaining selected commits manually and review/test before publishing, or prepare a fresh job with corrected selections.',
        'git cherry-pick --abort cancels this failing pick only; earlier successful picks remain in this isolated clone.'
    ]
    kinds = {
        (1, 2, 3): ('Both sides changed this file', 'Git could not reconcile the release contents with the selected commit. Changes may overlap, or source context may be absent from the release.'),
        (2, 3): ('Both sides added this path', 'The release and selected commit added different versions at the same path. Combine the intended contents or decide which addition belongs in this release.'),
        (1, 2): ('Incoming deletion versus release changes', 'The selected commit deletes this path, but the release has changes to it. Decide whether to retain the release file or intentionally delete it.'),
        (1, 3): ('Release deletion versus incoming changes', 'The release lacks this path, while the selected commit modifies it. Decide whether to restore the required code or keep the deletion.'),
    }
    files = []
    for path, stages in list(entries.items())[:20]:
        kind, explanation = kinds.get(tuple(sorted(stages)), ('Structural conflict', 'Review related paths for a rename, deletion, file-type change or submodule conflict.'))
        versions = {}
        binary = False
        for stage, label in ((1, 'base'), (2, 'release'), (3, 'incoming')):
            entry = stages.get(stage)
            if not entry:
                versions[label] = {'text': '(Path absent at this index stage)', 'mode': None, 'truncated': False}
                continue
            mode, blob = entry
            contents = (('Submodule commit: ' + blob).encode() if mode == '160000' else read('cat-file', 'blob', blob))
            is_binary = b'\0' in contents
            binary |= is_binary
            versions[label] = {'text': '(Binary contents; inspect with a suitable file comparison tool)' if is_binary else contents[:30000].decode('utf-8', errors='replace'),
                               'mode': mode, 'truncated': len(contents) > 30000, 'sha': blob}
        if binary:
            explanation += ' Binary contents are involved; text-marker editing may not apply.'
        patch = text('show', '--format=', '--no-ext-diff', '--no-textconv', '--no-color', sha, '--', path)
        markers = text('diff', '--cc', '--no-ext-diff', '--no-textconv', '--no-color', '--', path)
        history = text('log', '-5', '--format=%h %s', parents[0], '--', path) if parents else '(Root commit has no earlier source history.)'
        files.append(dict(path=path, kind=kind, explanation=explanation, versions=versions,
                          patch=patch[:30000], conflict_diff=markers[:30000], history=history,
                          truncated=len(patch) > 30000 or len(markers) > 30000))
    return dict(commit=sha, subject=text('show', '-s', '--format=%s', sha), files=files,
                truncated=len(entries) > 20, guidance=guidance)


def print_conflict_report(report):
    print(f"Conflict in {report['commit']}: {report['subject']}\n")
    for item in report['guidance']:
        print('- ' + item)
    for file in report['files']:
        print(f"\n## {file['path']}\n{file['kind']}: {file['explanation']}")
        for label, value in [('Incoming commit patch', file['patch']), ('Conflicting sections', file['conflict_diff']),
                             ('Earlier source commits touching this file (investigation leads, not proven dependencies)', file['history'])]:
            print(f'\n### {label}\n{value}')
        for label, version in file['versions'].items():
            print(f"\n### {label} version (mode {version['mode']})\n{version['text']}")
            if version['truncated']:
                print('[Preview truncated]')
        if file['truncated']:
            print('[Diff preview truncated]')
    if report['truncated']:
        print('[Showing only the first 20 conflicted paths]')


def validate(data):
    if not isinstance(data, dict):
        raise ValueError('Expected a JSON object.')
    for key in ('repo', 'base', 'source', 'branch', 'name', 'email', 'token'):
        value = data.get(key)
        if not isinstance(value, str) or not value.strip() or any(ord(c) < 32 for c in value):
            raise ValueError(f'Missing or invalid {key}.')
    if (not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9-]*/[A-Za-z0-9_.-]+', data['repo'])
            or data['repo'].split('/')[-1] in ('.', '..')):
        raise ValueError('Repository must be owner/repository on github.com.')
    for key in ('base', 'source', 'branch'):
        value = data[key]
        if value.startswith('-') or subprocess.run(
            git_command() + ['check-ref-format', 'refs/heads/' + value], capture_output=True, **process_options()
        ).returncode:
            raise ValueError(f'Invalid {key} branch name.')
    if data['branch'] in (data['base'], data['source']):
        raise ValueError('Output branch must be new and different from the base and source.')
    if not re.fullmatch(r'[^\s<>@]+@[^\s<>@]+', data['email']) or any(c in data['name'] for c in '<>'):
        raise ValueError('Enter a valid Git committer name and email.')
    picks = data.get('commits')
    if not isinstance(picks, list) or not picks or len(picks) > 1000:
        raise ValueError('Select between 1 and 1000 commits.')
    if any(not isinstance(s, str) or not re.fullmatch('[0-9a-f]{40}', s) for s in picks):
        raise ValueError('Each selected commit must have its full 40-character SHA.')
    if len(set(picks)) != len(picks):
        raise ValueError('Duplicate selected commits.')


class Job:
    def __init__(self, data, root, remote=None):
        self.lock = threading.Lock()
        self.token = data['token']
        self.data = {k: v for k, v in data.items() if k != 'token'}
        self.remote = remote or f"https://github.com/{data['repo']}.git"
        self.path = Path(tempfile.mkdtemp(prefix='merge-', dir=root)) / 'repo'
        self.state = dict(id=secrets.token_hex(16), state='preparing', logs=[],
                          repo=data['repo'], branch=data['branch'], base=data['base'], source=data['source'],
                          path=str(self.path), conflicts=[], applied=[])

    def update(self, **values):
        with self.lock:
            self.state.update(values)

    def log(self, message):
        # Never expose access credentials in command diagnostics.
        message = message.replace(self.token, '[redacted]') if self.token else message
        with self.lock:
            self.state['logs'].append(message)

    def snapshot(self):
        with self.lock:
            return copy.deepcopy(self.state)

    def git(self, *args, cwd=True, check=True):
        env = {k: v for k, v in os.environ.items() if not k.startswith('GIT_')}
        env.update(GIT_TERMINAL_PROMPT='0', GIT_EDITOR='true', GIT_CONFIG_NOSYSTEM='1',
                   GIT_CONFIG_GLOBAL=os.devnull, GIT_LFS_SKIP_SMUDGE='1', LC_ALL='C')
        # Credentials exist only in the subprocess environment, never argv or .git/config.
        auth = base64.b64encode(('x-access-token:' + self.token).encode()).decode()
        env.update(GIT_CONFIG_COUNT='1', GIT_CONFIG_KEY_0='http.https://github.com/.extraheader',
                   GIT_CONFIG_VALUE_0='Authorization: Basic ' + auth)
        cmd = git_command() + ['-c', 'core.longpaths=true', '-c', 'core.autocrlf=false', '-c', 'core.hooksPath=' + os.devnull, '-c', 'credential.helper=',
               '-c', 'http.followRedirects=false', *args]
        try:
            result = subprocess.run(cmd, cwd=self.path if cwd else None, env=env,
                                    capture_output=True, text=True, encoding='utf-8', errors='replace', timeout=1800, **process_options())
        except subprocess.TimeoutExpired as exc:
            raise GitError('Git timed out. Inspect the local checkout and remote branch before retrying.') from exc
        output = (result.stdout + result.stderr).strip().replace(auth, '[redacted]')
        if self.token:
            output = output.replace(self.token, '[redacted]')
        if check and result.returncode:
            raise GitError(f"git {args[0]} failed (exit {result.returncode}):\n{output}")
        if result.returncode:
            return result.returncode, output
        # Successful Git commands can emit warnings on stderr. Keep them in the
        # log, never in machine-readable SHA/ref/status output.
        warning = result.stderr.strip().replace(auth, '[redacted]')
        stdout = result.stdout.strip().replace(auth, '[redacted]')
        if self.token:
            warning = warning.replace(self.token, '[redacted]')
            stdout = stdout.replace(self.token, '[redacted]')
        if warning:
            self.log(warning)
        return 0, stdout

    def prepare(self):
        try:
            self.log('Cloning repository into ' + str(self.path))
            self.git('clone', '--no-checkout', '--origin', 'origin', '--', self.remote, str(self.path), cwd=False)
            if self.git('ls-remote', '--heads', 'origin', 'refs/heads/' + self.data['branch'])[1]:
                raise GitError('Output branch already exists. Choose a new version name.')
            self.git('config', 'merge.renameLimit', '999999')
            self.git('config', 'user.name', self.data['name'])
            self.git('config', 'user.email', self.data['email'])
            self.git('config', 'commit.gpgSign', 'false')
            base = self.git('rev-parse', '--verify', 'refs/remotes/origin/' + self.data['base'] + '^{commit}')[1]
            source = self.git('rev-parse', '--verify', 'refs/remotes/origin/' + self.data['source'] + '^{commit}')[1]
            self.update(base_sha=base, source_sha=source)
            requested = set(self.data['commits'])
            history = self.git('rev-list', '--topo-order', '--reverse', source)[1].splitlines()
            ordered = [sha for sha in history if sha in requested]
            missing = requested - set(ordered)
            if missing:
                raise GitError('Selected commits are not reachable from the source branch: ' + ', '.join(sorted(missing)))
            for sha in ordered:
                parents = self.git('rev-list', '--parents', '-n', '1', sha)[1].split()[1:]
                if len(parents) > 1:
                    raise GitError(f'{sha} is a merge commit. Choose its individual commits or cherry-pick it manually with an explicit mainline parent.')
            self.update(ordered=ordered)
            self.git('switch', '--no-track', '--create', self.data['branch'], base)
            applied = []
            for sha in ordered:
                self.update(current_commit=sha)
                self.log('Cherry-picking ' + sha)
                code, output = self.git('cherry-pick', '-x', sha, check=False)
                self.log(output)
                if code:
                    conflicts = self.git('diff', '--name-only', '--diff-filter=U', '-z')[1].split('\0')
                    conflicts = [p for p in conflicts if p]
                    if conflicts:
                        try:
                            self.update(conflict_report=describe_conflicts(self.path))
                        except Exception as exc:
                            self.log('Conflict details unavailable: ' + str(exc))
                    self.update(state='conflict' if conflicts else 'error', conflicts=conflicts,
                                error=f'Cherry-pick stopped at {sha}. ' + (
                                    'Resolve the listed conflicts in the local checkout; nothing was pushed.' if conflicts else
                                    'The commit may be empty/already applied, or Git failed. See the log; nothing was pushed.'))
                    return
                new_sha = self.git('rev-parse', 'HEAD')[1]
                message = self.git('show', '-s', '--format=%B', sha)[1]
                applied.append(dict(source=sha, sha=new_sha, message=message))
                self.update(applied=list(applied))
            head = self.git('rev-parse', 'HEAD')[1]
            summary = self.git('diff', '--stat', base, head)[1]
            diff = self.git('diff', '--no-ext-diff', '--no-textconv', '--no-color', base, head)[1]
            self.update(state='ready', head=head, summary=summary, diff=diff[:250000],
                        diff_truncated=len(diff) > 250000, current_commit=None)
            self.log('All selected commits applied. Review the diff and test the checkout before publishing.')
        except Exception as exc:
            self.update(state='error', error=str(exc))
            self.log(str(exc))
        finally:
            with self.lock:
                if self.state['state'] != 'publishing':
                    self.token = ''

    def start_publish(self, token):
        with self.lock:
            if self.state['state'] != 'ready':
                raise ValueError('Only a successfully prepared, unpublished job can be published.')
            self.state['state'] = 'publishing'
            self.token = token

    def publish(self):
        try:
            expected = self.snapshot()['head']
            if self.git('rev-parse', 'HEAD')[1] != expected or self.git('status', '--porcelain')[1]:
                raise GitError('The reviewed checkout changed. Prepare a new version before publishing.')
            ref = 'refs/heads/' + self.data['branch']
            if self.git('ls-remote', '--heads', 'origin', ref)[1]:
                raise GitError('Output branch already exists. Nothing was overwritten.')
            # An empty expected value is a create-only compare-and-swap. Even if
            # another user creates the branch after ls-remote, Git rejects our push.
            self.log('Publishing new branch ' + self.data['branch'])
            self.git('push', '--set-upstream', '--force-with-lease=' + ref + ':',
                     'origin', expected + ':' + ref)
            remote_sha = self.git('ls-remote', '--heads', 'origin', ref)[1].split()
            if not remote_sha or remote_sha[0] != expected:
                raise GitError('Push completed but remote verification failed. Inspect GitHub before retrying.')
            self.git('config', f"branch.{self.data['branch']}.remote", 'origin')
            self.git('config', f"branch.{self.data['branch']}.merge", ref)
            self.update(state='published', link=f"https://github.com/{self.data['repo']}/tree/{self.data['branch']}")
            self.log('Published and verified remote branch at ' + expected)
        except Exception as exc:
            self.update(state='error', error=str(exc))
            self.log(str(exc))
        finally:
            self.token = ''


class NoRedirect(HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


class Handler(BaseHTTPRequestHandler):
    def log_message(self, *args):
        pass  # Launch URL and authentication headers must not be logged.

    def send(self, status, data, content_type='application/json'):
        body = json.dumps(data).encode() if content_type == 'application/json' else data
        self.send_response(status)
        self.send_header('Content-Type', content_type)
        self.send_header('Content-Length', str(len(body)))
        self.send_header('Cache-Control', 'no-store')
        self.send_header('X-Content-Type-Options', 'nosniff')
        self.end_headers()
        self.wfile.write(body)

    def authenticated(self):
        if self.headers.get('Host') != f'127.0.0.1:{self.server.server_port}':
            return False
        cookies = SimpleCookie()
        try:
            cookies.load(self.headers.get('Cookie', ''))
            value = cookies['merger_session'].value if 'merger_session' in cookies else ''
            return hmac.compare_digest(value, self.server.secret)
        except Exception:
            return False

    def do_GET(self):
        parsed = urlsplit(self.path)
        supplied = parse_qs(parsed.query).get('session', [''])[0]
        if parsed.path == '/' and hmac.compare_digest(supplied, self.server.secret):
            self.send_response(303)
            self.send_header('Set-Cookie', f'merger_session={self.server.secret}; HttpOnly; SameSite=Strict; Path=/')
            self.send_header('Location', '/merger.html')
            self.send_header('Cache-Control', 'no-store')
            self.send_header('Content-Length', '0')
            self.end_headers()
            return
        if not self.authenticated():
            self.send(401, {'error': 'Open the local launch URL printed by merger_server.py.'})
            return
        if parsed.path in ('/', '/merger.html'):
            html = Path(__file__).with_name('merger.html').read_text(encoding='utf-8')
            html = html.replace('<head>', '<head><script>window.MERGER_SESSION=' + json.dumps(self.server.secret) + ';</script>', 1)
            self.send(200, html.encode(), 'text/html; charset=utf-8')
        elif re.fullmatch(r'/assets/[a-zA-Z0-9_.-]+', parsed.path):
            asset = Path(__file__).resolve().parent / 'assets' / parsed.path.rsplit('/', 1)[-1]
            if asset.is_file() and asset.suffix in ('.js', '.css'):
                self.send(200, asset.read_bytes(), ('application/javascript' if asset.suffix == '.js' else 'text/css') + '; charset=utf-8')
            else:
                self.send(404, {'error': 'Asset not found'})
        elif parsed.path == '/api/merger/health':
            self.send(200, {'ok': True})
        elif parsed.path.startswith('/api/merger/jobs/'):
            job = self.server.jobs.get(parsed.path.rsplit('/', 1)[-1])
            self.send(200, job.snapshot()) if job else self.send(404, {'error': 'Unknown job. Prepare again after restarting the server.'})
        else:
            self.send(404, {'error': 'Not found'})

    def do_POST(self):
        if (not self.authenticated() or
                not hmac.compare_digest(self.headers.get('X-Merger-Session', ''), self.server.secret) or
                self.headers.get('Origin', f'http://127.0.0.1:{self.server.server_port}') != f'http://127.0.0.1:{self.server.server_port}'):
            self.send(403, {'error': 'Invalid local session. Open the server launch URL.'})
            return
        try:
            length = int(self.headers.get('Content-Length', '0'))
            if not 0 < length <= 200000:
                raise ValueError('Invalid request size.')
            data = json.loads(self.rfile.read(length))
            if self.path == '/api/merger/jobs':
                validate(data)
                job = Job(data, self.server.work_root)
                self.server.jobs[job.state['id']] = job
                threading.Thread(target=job.prepare, daemon=True).start()
                self.send(202, job.snapshot())
            elif re.fullmatch(r'/api/merger/jobs/[a-f0-9]{32}/publish', self.path):
                job = self.server.jobs.get(self.path.split('/')[-2])
                if not job:
                    raise ValueError('Unknown job.')
                token = data.get('token')
                if not isinstance(token, str) or not token or any(ord(c) < 32 for c in token):
                    raise ValueError('GitHub token is required.')
                job.start_publish(token)
                threading.Thread(target=job.publish, daemon=True).start()
                self.send(202, job.snapshot())
            elif self.path == '/api/merger/jira':
                self.jira_sync(data)
            else:
                self.send(404, {'error': 'Not found'})
        except (ValueError, TypeError, KeyError) as exc:
            self.send(400, {'error': str(exc)})
        except Exception as exc:
            self.send(500, {'error': str(exc)})

    def jira_sync(self, data):
        job = self.server.jobs.get(data.get('job'))
        if not job or job.snapshot()['state'] != 'published':
            raise ValueError('Jira can only be updated after verified publication.')
        domain = data.get('domain', '')
        if not isinstance(domain, str) or not re.fullmatch(r'[a-zA-Z0-9-]+\.atlassian\.net', domain):
            raise ValueError('Enter a Jira Cloud domain, e.g. team.atlassian.net.')
        user, token = data.get('user', ''), data.get('token', '')
        if not isinstance(user, str) or not isinstance(token, str) or not user or not token:
            raise ValueError('Jira credentials are required.')
        auth = base64.b64encode((user + ':' + token).encode()).decode()
        opener = build_opener(NoRedirect())
        def api(path, method='GET', payload=None):
            req = Request('https://' + domain + '/rest/api/2/issue/' + path,
                          data=json.dumps(payload).encode() if payload is not None else None,
                          headers={'Authorization': 'Basic ' + auth, 'Content-Type': 'application/json'}, method=method)
            with opener.open(req, timeout=30) as response:
                body = response.read()
                return json.loads(body) if body else {}
        results = []
        issues = {}
        for pick in job.snapshot()['applied']:
            for key in re.findall(r'\bISCAR-\d+\b', pick['message'], re.I):
                issues.setdefault(key.upper(), []).append(pick['source'])
        for key, shas in issues.items():
            try:
                issue = api(key)
                old = issue['fields'].get('customfield_10124')
                if old is not None and not isinstance(old, str):
                    raise ValueError('Jira revision field is not a text field.')
                revisions = [v.strip() for v in (old or '').split(',') if v.strip()]
                branch = job.data['branch']
                if branch not in revisions:
                    api(key, 'PUT', {'fields': {'customfield_10124': ', '.join(revisions + [branch])}})
                links = '\n'.join(f"https://github.com/{job.data['repo']}/commit/{sha}" for sha in dict.fromkeys(shas))
                api(key + '/comment', 'POST', {'body': f"🚀 *Deployment Notification*\n\nBranch: {job.snapshot()['link']}\nSource commits:\n{links}"})
                results.append(f'Jira updated: {key}')
            except HTTPError as exc:
                results.append(f'Jira failed for {key}: HTTP {exc.code}. Branch remains published.')
            except Exception:
                results.append(f'Jira failed for {key}. Check connection, credentials and revision field. Branch remains published.')
        self.send(200, {'logs': results})


def make_server(port, root):
    root = Path(root).expanduser().resolve()
    root.mkdir(parents=True, exist_ok=True, mode=0o700)
    server = ThreadingHTTPServer(('127.0.0.1', port), Handler)
    server.secret = secrets.token_hex(32)
    server.jobs = {}
    server.work_root = root
    return server


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--port', type=int, default=8765)
    parser.add_argument('--work-dir', default=default_work_dir())
    parser.add_argument('--no-browser', action='store_true')
    parser.add_argument('--inspect-conflict', metavar='CHECKOUT', help='Print read-only conflict advice for an existing checkout and exit.')
    args = parser.parse_args()
    if args.inspect_conflict:
        try:
            print_conflict_report(describe_conflicts(args.inspect_conflict))
        except (GitError, OSError, subprocess.TimeoutExpired) as exc:
            parser.exit(1, str(exc) + '\n')
        return
    server = make_server(args.port, args.work_dir)
    url = f'http://127.0.0.1:{server.server_port}/?session={server.secret}'
    print('Open this local URL:\n' + url, flush=True)
    print('Isolated checkouts: ' + str(server.work_root), flush=True)
    if not args.no_browser:
        threading.Timer(0.5, lambda: webbrowser.open(url)).start()
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()


if __name__ == '__main__':
    main()
