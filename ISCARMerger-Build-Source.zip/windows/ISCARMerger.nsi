; Self-contained user-local launcher; no administrator rights or PATH modifications.
Unicode true
Target amd64-unicode
!include "x64.nsh"
Name "ISCAR Merger"
OutFile "${OUTPUT_EXE}"
InstallDir "$LOCALAPPDATA\ISCARMerger\app-${BUILD_ID}"
RequestExecutionLevel user
SetCompressor /SOLID lzma
AutoCloseWindow true
ShowInstDetails nevershow
BrandingText "ISCAR Merger — Git cherry-pick release tool"
Page instfiles

Function .onInit
  ${IfNot} ${RunningX64}
    MessageBox MB_OK|MB_ICONSTOP "ISCAR Merger requires 64-bit Windows."
    Abort
  ${EndIf}
FunctionEnd

Section
  IfFileExists "$INSTDIR\package.complete" launch
  SetOutPath "$INSTDIR"
  ClearErrors
  File /r "${APP_DIR}/*"
  IfErrors failed
  FileOpen $0 "$INSTDIR\package.complete" w
  FileWrite $0 "${BUILD_ID}"
  FileClose $0
launch:
  SetOutPath "$INSTDIR"
  CreateShortcut "$DESKTOP\ISCAR Merger.lnk" "$INSTDIR\python\python.exe" '"$INSTDIR\launch_windows.py"'
  ClearErrors
  Exec '"$INSTDIR\python\python.exe" -u "$INSTDIR\launch_windows.py"'
  IfErrors failed
  Goto done
failed:
  MessageBox MB_OK|MB_ICONSTOP "Could not unpack or launch ISCAR Merger. Check free disk space and access to your Local AppData folder."
  SetErrorLevel 1
done:
SectionEnd
