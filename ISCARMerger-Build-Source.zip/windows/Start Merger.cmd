@echo off
"%~dp0python\python.exe" -u "%~dp0launch_windows.py"
if errorlevel 1 pause
