r"""Exercise bundled Windows Python/Git against temporary local repositories only.
Usage: APP\python\python.exe windows\smoke_test.py APP
"""
import os
from pathlib import Path
import subprocess
import sys
import tempfile

sys.path.insert(0, str(Path(sys.argv[1]).resolve()))
import merger_server

if hasattr(sys.stdout, 'reconfigure'):
    sys.stdout.reconfigure(encoding='utf-8')

def git(repo, *args):
    env = os.environ.copy()
    env.update(GIT_CONFIG_GLOBAL=os.devnull, GIT_CONFIG_NOSYSTEM='1')
    p = subprocess.run(merger_server.git_command() + ['-C', str(repo), '-c', 'core.autocrlf=false', *args],
                       env=env, capture_output=True, text=True, encoding='utf-8', errors='replace', timeout=120)
    if p.returncode:
        raise RuntimeError(p.stdout + p.stderr)
    return p.stdout.strip()

with tempfile.TemporaryDirectory(prefix='merger-windows-test-') as folder:
    root = Path(folder)
    repo = root / 'source'
    repo.mkdir()
    git(repo, 'init', '-b', 'main')
    git(repo, 'config', 'user.name', 'Smoke Test')
    git(repo, 'config', 'user.email', 'smoke@example.com')
    lines = [f'line {i}\n' for i in range(40)]
    (repo / 'shared.txt').write_text(''.join(lines), encoding='utf-8')
    git(repo, 'add', '.')
    git(repo, 'commit', '-m', 'Initial')
    git(repo, 'branch', 'release')
    lines[0] = 'unselected feature\n'
    (repo / 'shared.txt').write_text(''.join(lines), encoding='utf-8')
    git(repo, 'commit', '-am', 'Unselected')
    lines[20] = 'selected fix\n'
    (repo / 'shared.txt').write_text(''.join(lines), encoding='utf-8')
    git(repo, 'commit', '-am', 'Selected')
    pick = git(repo, 'rev-parse', 'HEAD')
    git(repo, 'switch', 'release')
    release = [f'line {i}\n' for i in range(40)]
    release[39] = 'release-only fix\n'
    (repo / 'shared.txt').write_text(''.join(release), encoding='utf-8')
    git(repo, 'commit', '-am', 'Release fix')
    remote = root / 'remote.git'
    git(root, 'init', '--bare', str(remote))
    git(repo, 'remote', 'add', 'origin', str(remote))
    git(repo, 'push', 'origin', '--all')
    data = dict(repo='smoke/test', token='', base='release', source='main', branch='next',
                name='Smoke Committer', email='committer@example.com', commits=[pick])
    job = merger_server.Job(data, root, remote=str(remote))
    job.prepare()
    assert job.snapshot()['state'] == 'ready', job.snapshot()
    actual = (job.path / 'shared.txt').read_text(encoding='utf-8')
    assert 'unselected feature' not in actual
    assert 'selected fix' in actual and 'release-only fix' in actual
    job.start_publish('')
    job.publish()
    assert job.snapshot()['state'] == 'published', job.snapshot()
    assert git(remote, 'rev-parse', 'refs/heads/next') == job.snapshot()['head']
    duplicate = merger_server.Job(data, root, remote=str(remote))
    duplicate.prepare()
    assert duplicate.snapshot()['state'] == 'error'
    assert 'already exists' in duplicate.snapshot()['error']
    print('PASS: bundled Windows Git prepares only selected changes, preserves release fixes, publishes to a local bare remote, and rejects existing branches.')
