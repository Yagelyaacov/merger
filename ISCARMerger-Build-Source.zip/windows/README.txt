ISCAR MERGER — WINDOWS x64

1. Double-click ISCARMerger-Windows-x64.exe.
2. The application unpacks into your Local AppData folder and opens your browser.
3. Keep the ISCAR Merger console window open while preparing or publishing.
4. Connect with your GitHub token and repository. Jira is optional.
5. Select your base/source/commits, prepare, review and test, then publish.

Python, Git and interface scripts are included. No separate Python or Git
installation is required. Internet access is required for GitHub and Jira.
The interface opens in your default browser; this is not an embedded browser.
Supported target: Windows 10/11 x64.

The first launch creates an ISCAR Merger desktop shortcut.
Application files: %LOCALAPPDATA%\ISCARMerger\app-BUILD_ID
Git checkouts:     %LOCALAPPDATA%\ISCARMerger\jobs
The app does not modify system PATH and does not require administrator rights.
Close its console AFTER running Git operations finish. Closing the browser
alone leaves the local server running. Reopening the launcher starts a new
session; it does not recover an earlier session's job tracking.

The executable is unsigned. Corporate Windows policies or SmartScreen may
require your organization's approval. Use the supplied SHA256 file to verify
that your copy matches the delivered build.

PORTABLE ZIP
Extract the ZIP to a writable folder. Run Start Merger.cmd. Keep the whole
folder together. This performs no installation and creates no shortcut.

MANUAL GIT COMMANDS
Use the bundled Git executable when Git is not otherwise installed:
  "PATH_TO_APP\git\cmd\git.exe" -C "PATH_TO_CHECKOUT" status
  "PATH_TO_APP\git\cmd\git.exe" -C "PATH_TO_CHECKOUT" cherry-pick --continue
Resolve conflicts deliberately before continuing. The browser does not resume
a manually resolved job. No automatic AI analysis or resolution is performed.

For conflict advice, run the bundled runtime:
  "PATH_TO_APP\python\python.exe" "PATH_TO_APP\merger_server.py" --inspect-conflict "PATH_TO_CHECKOUT"

COPYRIGHT / THIRD PARTY SOFTWARE
Original third-party licenses remain under python\, git\ and licenses\.
The downloads.json file records exact source distribution URLs and SHA256s.
Python: https://www.python.org/ (PSF License)
MinGit: https://gitforwindows.org/mingit.html (Git GPLv2 and bundled licenses)
Git source for this release:
https://github.com/git-for-windows/git/tree/v2.55.0.windows.5
React / React DOM, Babel, Tailwind CSS: MIT licenses in licenses\.
NSIS launcher: https://nsis.sourceforge.io/ (zlib/libpng license).

BUILDING AN UPDATED EXE
Requires Python 3.9+ and NSIS 3.11+ on the build machine only.
  python windows/build_windows.py --makensis PATH_TO_MAKENSIS
The script verifies pinned downloads, bundles the current merger files,
and writes the EXE, checksum and portable ZIP under dist\.

To remove the app, first close its consoles, then delete its app-BUILD_ID
folders and desktop shortcut. Keep the jobs folder if you need the checkouts.

This package does not include your GitHub/Jira credentials, project source
checkout, browser state or deployment job data.
