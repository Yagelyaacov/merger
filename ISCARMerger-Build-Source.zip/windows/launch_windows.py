"""Entry point for the bundled Windows runtime; keeps startup failures visible."""
import ctypes
import os
from pathlib import Path
import sys
import traceback

app_dir = Path(__file__).resolve().parent
sys.path.insert(0, str(app_dir))
os.chdir(app_dir)
for stream in (sys.stdout, sys.stderr):
    if stream and hasattr(stream, 'reconfigure'):
        stream.reconfigure(encoding='utf-8', errors='replace')
if os.name == 'nt':
    ctypes.windll.kernel32.SetConsoleTitleW('ISCAR Merger — keep this window open while working')

try:
    import merger_server
    # Select an unused port so other local tools or app copies do not block startup.
    if '--port' not in sys.argv:
        sys.argv.extend(['--port', '0'])
    print('ISCAR Merger\nKeep this window open while using the app. Close it after all Git operations finish.\n', flush=True)
    merger_server.main()
except Exception:
    traceback.print_exc()
    if os.name == 'nt':
        ctypes.windll.user32.MessageBoxW(None, 'ISCAR Merger could not start. See the console for details.', 'ISCAR Merger', 0x10)
    input('Press Enter to close...')
    raise SystemExit(1)
