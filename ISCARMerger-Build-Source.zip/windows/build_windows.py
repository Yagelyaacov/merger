#!/usr/bin/env python3
"""Build a self-contained Windows launcher with NSIS (runs on Linux or Windows)."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import urllib.request
import zipfile

ROOT = Path(__file__).resolve().parents[1]


def download(name, entry, cache):
    destination = cache / name
    if not destination.exists():
        print('Downloading ' + name, flush=True)
        urllib.request.urlretrieve(entry['url'], destination)
    digest = hashlib.sha256(destination.read_bytes()).hexdigest()
    if not entry.get('sha256') or digest != entry['sha256']:
        raise ValueError(f'{name}: SHA256 mismatch or missing pinned hash; received {digest}')
    return destination


def prepare(root, cache):
    manifest = json.loads((ROOT / 'windows/downloads.json').read_text())
    cache.mkdir(parents=True, exist_ok=True)
    if root.exists():
        shutil.rmtree(root)
    root.mkdir(parents=True)
    (root / 'assets').mkdir()
    (root / 'licenses').mkdir()
    compiler_name = 'tailwindcss-windows-x64.exe' if os.name == 'nt' else 'tailwindcss-linux-x64'
    for name, entry in manifest.items():
        if entry.get('build_tool') and name != compiler_name:
            continue
        source = download(name, entry, cache)
        if entry.get('build_tool'):
            continue
        if name in ('python.zip', 'mingit.zip'):
            target = root / ('python' if name == 'python.zip' else 'git')
            with zipfile.ZipFile(source) as archive:
                # Files originate in pinned official distributions; disallow traversal regardless.
                for info in archive.infolist():
                    if not (target / info.filename).resolve().is_relative_to(target.resolve()):
                        raise ValueError('Unsafe archive path')
                archive.extractall(target)
        else:
            shutil.copy2(source, root / ('assets' if name.endswith('.js') else 'licenses') / name)
    shutil.copy2(ROOT / 'merger_server.py', root / 'merger_server.py')
    shutil.copy2(ROOT / 'windows/launch_windows.py', root / 'launch_windows.py')
    shutil.copy2(ROOT / 'windows/README.txt', root / 'README.txt')
    shutil.copy2(ROOT / 'windows/Start Merger.cmd', root / 'Start Merger.cmd')
    shutil.copy2(ROOT / 'windows/downloads.json', root / 'licenses/downloads.json')
    # The embeddable distribution uses an isolated sys.path; explicitly include the application.
    (root / 'python/python313._pth').write_text('python313.zip\n.\n..\nimport site\n', encoding='utf-8')
    html = (ROOT / 'merger.html').read_text(encoding='utf-8')
    replacements = {
        'https://unpkg.com/react@18/umd/react.production.min.js': '/assets/react.js',
        'https://unpkg.com/react-dom@18/umd/react-dom.production.min.js': '/assets/react-dom.js',
        'https://unpkg.com/@babel/standalone/babel.min.js': '/assets/babel.js',
    }
    for original, bundled in replacements.items():
        if original not in html:
            raise ValueError('Expected UI dependency missing: ' + original)
        html = html.replace(original, bundled)
    html = html.replace('<script src="https://cdn.tailwindcss.com"></script>', '<link rel="stylesheet" href="/assets/tailwind.css">')
    html = re.sub(r"\s*@import url\('https://fonts.googleapis.com/[^']+'\);", '', html)
    html = html.replace('Run <code>python3 merger_server.py</code> and use its local URL.',
                        'ISCAR Merger for Windows. Keep the launcher window open while working.')
    (root / 'merger.html').write_text(html, encoding='utf-8')
    compiler = cache / compiler_name
    compiler.chmod(0o755)
    css_input = root.parent / 'tailwind-input.css'
    css_input.write_text('@tailwind base;\n@tailwind components;\n@tailwind utilities;\n')
    config = root.parent / 'tailwind.config.cjs'
    config.write_text('module.exports = ' + json.dumps({'content': [str(ROOT / 'merger.html')], 'theme': {'extend': {}}, 'plugins': []}) + ';\n')
    subprocess.run([str(compiler), '-c', str(config), '-i', str(css_input), '-o', str(root / 'assets/tailwind.css'), '--minify'], check=True)
    for file in ('git/cmd/git.exe', 'python/python.exe', 'python/python313.dll'):
        if not (root / file).is_file():
            raise ValueError('Required bundled executable missing: ' + file)
    digest = hashlib.sha256()
    for path in sorted(root.rglob('*')):
        if path.is_file():
            digest.update(path.relative_to(root).as_posix().encode())
            digest.update(path.read_bytes())
    return digest.hexdigest()[:12]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--makensis', default=shutil.which('makensis') or shutil.which('makensis.exe'))
    parser.add_argument('--build-dir', type=Path, default=ROOT / 'build/merger-windows')
    parser.add_argument('--output-dir', type=Path, default=ROOT / 'dist')
    parser.add_argument('--prepare-only', action='store_true')
    args = parser.parse_args()
    build = args.build_dir.resolve()
    stage = build / 'app'
    build_id = prepare(stage, build / 'downloads')
    print('Prepared app bundle ' + build_id, flush=True)
    if args.prepare_only:
        return
    if not args.makensis:
        parser.error('Install NSIS 3 and provide --makensis PATH_TO_MAKENSIS')
    output = args.output_dir.resolve()
    output.mkdir(parents=True, exist_ok=True)
    executable = output / 'ISCARMerger-Windows-x64.exe'
    prefix = '/D' if os.name == 'nt' else '-D'
    subprocess.run([args.makensis, prefix + 'APP_DIR=' + str(stage), prefix + 'BUILD_ID=' + build_id,
                    prefix + 'OUTPUT_EXE=' + str(executable), str(ROOT / 'windows/ISCARMerger.nsi')], check=True)
    digest = hashlib.sha256(executable.read_bytes()).hexdigest()
    (output / 'ISCARMerger-Windows-x64.sha256').write_text(f'{digest}  {executable.name}\n')
    shutil.copy2(ROOT / 'windows/README.txt', output / 'ISCARMerger-README.txt')
    # Also offer a portable directory package for managed desktops that block installers.
    shutil.make_archive(str(output / 'ISCARMerger-Windows-x64-portable'), 'zip', root_dir=stage)
    print(f'Built {executable} ({executable.stat().st_size / 1024 / 1024:.1f} MiB)', flush=True)


if __name__ == '__main__':
    main()
