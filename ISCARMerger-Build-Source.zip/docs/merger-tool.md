# Local cherry-pick merger

## Windows application

Use `dist/ISCARMerger-Windows-x64.exe` on Windows 10/11 x64. It bundles Python, MinGit and the UI assets. Double-click it; the application opens in your default browser and creates a desktop shortcut. Keep its console open while working. No separate Python/Git installation or administrator rights are required. GitHub/Jira still require internet access. This is a local browser interface, not an embedded desktop webview.

Checkouts are retained in `%LOCALAPPDATA%\ISCARMerger\jobs`. Application versions unpack beside that directory in `app-BUILD_ID` folders. The build is unsigned. A portable ZIP is also provided; extract it and run `Start Merger.cmd`.

For future builds, use `python windows/build_windows.py --makensis PATH_TO_MAKENSIS` with Python 3.9+ and NSIS 3.11+ on the build machine. The script verifies pinned distribution hashes, compiles the bundled stylesheet, and builds the EXE and portable ZIP. See `windows/README.txt` for launch, manual Git, recovery and removal details. Windows archives contain original third-party license files.

Packaged-runtime smoke test: `APP\python\python.exe windows\smoke_test.py APP`. It uses temporary repositories and a local bare remote, without GitHub credentials. The Windows package was exercised under Wine; a native Windows desktop validation remains recommended.

Run from the directory containing `merger.html` and `merger_server.py`:

```bash
python3 merger_server.py
```

Requires Python 3 and Git (with `git switch` support). No Python packages are required. The server opens a browser; otherwise use the authenticated local URL printed in the terminal. Keep that terminal running. Opening `merger.html` directly or through an unrelated web server does not enable Git operations. The interface still loads React, Babel, Tailwind and fonts from their existing internet CDNs.

For a different port or checkout directory:

```bash
python3 merger_server.py --port 8766 --work-dir /home/YOUR_USER/merge-jobs --no-browser
```

## Workflow

1. Connect using your GitHub token and `owner/repository`. The token needs repository read access and permission to create/push branches. Enter optional Jira credentials if you want notifications after publishing.
2. Choose the source branch, existing base release branch, and a **new** output branch name. The tool fills your Git committer name and email from the authenticated GitHub account when available. If GitHub does not provide an email, the tool uses your Jira login email. Identity fields appear only for missing details. The detected identity is displayed before preparation. Original commit authors are preserved.
3. Select commits. Use **Load older commits** if necessary. The Compare tab lists source commits absent from the target's ancestry. It uses the chosen source, not a hardcoded master branch. Previously cherry-picked commits can still appear because their SHAs differ.
4. Click **Prepare version**. A new independent clone is created under `~/.local/share/iscar-merger/`. Git checks every selected SHA, rejects merge commits, sets `merge.renameLimit=999999`, creates the output branch from the pinned base SHA, and applies only the selections with `git cherry-pick -x`, in ancestry order.
5. Review the resulting diff and commit mappings. Run the project's appropriate tests in the displayed local checkout. The tool does not run application tests automatically. Large diffs are truncated in the browser; the complete diff is available locally using the displayed base and head SHAs.
6. Click **Publish branch**. The server checks that the reviewed checkout is unchanged, pushes the exact reviewed commit, and verifies the remote SHA. Jira updates run only after verified publication. Jira errors are shown separately and do not undo a successful push.

Cloning fetches repository history so Git can calculate changes correctly. The output branch contains the base history plus the newly cherry-picked commits; source ancestors are not merged into it.

Publication is create-only. It uses an empty expected SHA in `--force-with-lease=refs/heads/NEW_BRANCH:` to reject any existing branch, including one created between checking and pushing. This is not an unconditional force push. Existing branches are never replaced.

## Stops and recovery

Conflicts stop at the failing SHA and display the conflicting paths and Git diagnostics. The conflict report explains the conflict type, shows the selected commit’s patch, conflicting sections, and Git’s common/release/incoming versions, and provides resolution steps. Recent source changes are shown as investigation leads, not automatically declared dependencies. No side is chosen automatically. Binary and large-file previews have explicit limitations. No branch is pushed, no later selections are applied, and Jira is not updated. Empty/already-applied commits also stop; the tool never silently skips a selection. Merge commits require a deliberate mainline choice and must be handled manually or replaced with their constituent commits.

The failed clone is retained for inspection. The browser does not resume manually resolved conflicts. Either prepare a fresh job with corrected selections, or finish the job manually in its displayed checkout. For manual completion, resolve the files, `git add` only the resolved paths, then `git cherry-pick --continue`. Apply remaining selected SHAs deliberately, review/test the complete diff, and publish separately. `git cherry-pick --abort` cancels only the currently failing pick because the service invokes picks one at a time; earlier successful picks remain in that disposable clone.

Prepared jobs are held in server memory. Restarting the server or refreshing/signing out of the page loses the browser's job review. Checkouts remain on disk. If the connection fails during publication, check the output branch on GitHub before retrying; the push may have completed even if its response was lost. A new preparation will reject an already-created branch.

GitHub and Jira tokens are held in memory, not local storage or clone configuration. The server binds only to `127.0.0.1` and uses a per-launch browser session. Git credentials are supplied in subprocess environment variables. The service does not reuse global Git credential helpers, hooks, filters, identity, or signing configuration. Repository files retain Git's regular-file modes, symlinks, binary contents and submodule references; submodules and Git LFS object contents are not downloaded automatically.

Completed and failed clones are not automatically deleted. Remove their displayed job directories when you no longer need them and no job is running.

## Verification

```bash
python3 -m unittest discover -s test/python -p 'test_merger_server.py' -v
node test/javascript/merger_ui.test.js
```

The Python integration tests use temporary repositories and local bare remotes. They check selective patch application, release-only changes, file operations, ancestry ordering, conflict/empty/merge stops, missing SHAs, rejected pushes, branch creation races, checkout changes, and HTTP session checks. The UI test uses Playwright with mocked GitHub/job responses; it does not contact a real repository or publish a branch.

To inspect an existing conflicted checkout without restarting a running server or modifying the checkout:

```bash
python3 merger_server.py --inspect-conflict /path/to/merge-job/repo
```

This prints the same read-only conflict advice in the terminal. Restart the local server to enable the new browser reports for future jobs; restarting loses in-memory job tracking, so inspect an active checkout first.

## Base branch indicators

Selecting a base branch scans its commit history, including all API pages, pinned to the first returned head SHA. Each source task shows an exact **In base history** match, **Cherry-pick recorded in base** for a source SHA recorded by `git cherry-pick -x`, **Possible match in base** for the same commit title and author date (legacy merger output), or a task reference such as **ISCAR-123 mentioned in base**. Matches link to the corresponding base commit.

Task references and legacy metadata are hints, not proof of equivalent code. Even exact history matches can have been reverted or modified later. **No history match** does not rule out squashed or manually applied changes. Indicators do not silently remove selections or skip commits. Use **Refresh base check** after the remote base changes; failures are shown as unavailable rather than missing.
