// Browser workflow regression: mocked GitHub/job responses, real local HTML server.
const assert = require('node:assert/strict');
const { spawn } = require('node:child_process');
const path = require('node:path');
const { chromium } = require('playwright');

(async () => {
    const root = path.resolve(__dirname, '../..');
    const server = process.env.MERGER_TEST_URL ? null : spawn('python3', ['merger_server.py', '--no-browser', '--port', '0'], { cwd: root });
    let browser;
    try {
        const url = process.env.MERGER_TEST_URL || await new Promise((resolve, reject) => {
            let output = '';
            const timer = setTimeout(() => reject(new Error('Server startup timed out')), 10000);
            server.stdout.on('data', chunk => {
                output += chunk;
                const match = output.match(/http:\/\/127\.0\.0\.1:\d+\/\?session=[a-f0-9]+/);
                if (match) { clearTimeout(timer); resolve(match[0]); }
            });
            server.on('error', reject);
        });
        browser = await chromium.launch({ headless: true });
        const page = await browser.newPage({ ignoreHTTPSErrors: true, viewport: { width: 1500, height: 1000 } });
        const errors = [];
        const externalAssets = [];
        page.on('request', request => {
            if (['script', 'stylesheet', 'font'].includes(request.resourceType()) && !request.url().startsWith('http://127.0.0.1:')) externalAssets.push(request.url());
        });
        page.on('pageerror', error => errors.push(error.message));
        const commits = Array.from({ length: 55 }, (_, i) => ({
            sha: (i + 1).toString(16).padStart(40, '0'),
            commit: { message: `Selected task ${i + 1}`, author: { name: 'Author', date: '2026-01-01T00:00:00Z' } }
        }));
        commits[3].commit.message += ' ISCAR-9999';
        const basePage = Array.from({ length: 100 }, (_, i) => ({ sha: (10000 + i).toString(16).padStart(40, '0'), commit: { message: `Base ${i}`, author: { date: '2025-01-01T00:00:00Z' } } }));
        let baseFailure = false;
        let identityMode = 'private';
        await page.route('https://api.github.com/**', async route => {
            const url = new URL(route.request().url());
            let data;
            if (url.pathname === '/user' && identityMode === 'unavailable') { await route.fulfill({ status: 403, json: { message: 'Forbidden' } }); return; }
            if (url.pathname === '/user') data = identityMode === 'public'
                ? { login: 'other-user', name: null, email: 'other@example.com' }
                : { login: 'release-user', name: 'Release User', email: null };
            else if (url.pathname === '/user/emails') {
                if (['denied', 'jira', 'invalid'].includes(identityMode)) { await route.fulfill({ status: 403, json: { message: 'Forbidden' } }); return; }
                data = [{ email: 'unverified@example.com', primary: false, verified: false },
                        { email: 'release@example.com', primary: true, verified: true }];
            }
            else if (url.pathname.endsWith('/branches')) data = ['main', 'feature', 'release'].map(name => ({ name }));
            else if (url.pathname.includes('/compare/')) data = { commits };
            else if (url.pathname.endsWith('/commits') && ['release', basePage[0].sha].includes(url.searchParams.get('sha'))) {
                if (baseFailure) { await route.fulfill({ status: 403, json: { message: 'Rate limited' } }); return; }
                data = url.searchParams.get('page') === '1' ? basePage : [commits[0],
                    { sha: 'd'.repeat(40), commit: { message: `Picked task\n\n(cherry picked from commit ${commits[1].sha})`, author: { date: '2024-01-01T00:00:00Z' } } },
                    { ...commits[2], sha: 'e'.repeat(40) },
                    { sha: 'f'.repeat(40), commit: { message: 'Other change for ISCAR-9999', author: { date: '2024-01-01T00:00:00Z' } } }];
            }
            else if (/\/commits\/[0-9a-f]+$/.test(url.pathname)) data = { files: [{ filename: 'shared.txt' }] };
            else data = commits.slice(0, 1);
            await route.fulfill({ json: data });
        });
        let preparePayload, publishCount = 0, mode = 'ready';
        const job = state => ({
            id: 'a'.repeat(32), state, logs: ['Cherry-picking selected commits'],
            branch: 'next', base: 'release', path: '/tmp/example/repo', conflicts: [],
            applied: commits.map(c => ({ source: c.sha, sha: c.sha, message: c.commit.message })),
            base_sha: 'b'.repeat(40), head: 'c'.repeat(40), summary: 'shared.txt | 1 +',
            diff: '+selected change only', link: 'https://github.com/test/repo/tree/next',
            ...(state === 'conflict' ? { conflicts: ['shared.txt'], current_commit: commits[0].sha, error: 'Cherry-pick stopped. Nothing was pushed.',
                conflict_report: { subject: 'Selected task conflict', guidance: ['Review the incoming patch before resolving.'], files: [{
                    path: 'shared.txt', kind: 'Both sides changed this file', explanation: 'Source context may be absent.',
                    patch: '+selected fix', conflict_diff: '<<<<<<< HEAD\nrelease change\n=======\nsource change\n>>>>>>> selected',
                    versions: Object.fromEntries(['base', 'release', 'incoming'].map(key => [key, { text: key + ' contents', mode: '100644' }])),
                    history: '123abc Earlier feature'
                }] }
            } : {})
        });
        await page.route('**/api/merger/jobs**', async route => {
            const request = route.request();
            if (request.url().endsWith('/publish')) {
                publishCount++;
                await route.fulfill({ json: job('published') });
            } else if (request.method() === 'POST') {
                preparePayload = request.postDataJSON();
                await route.fulfill({ json: job('preparing') });
            } else await route.fulfill({ json: job(mode) });
        });
        await page.goto(url);
        if (process.env.MERGER_TEST_URL) {
            await page.getByRole('heading', { name: 'Merger Connection' }).waitFor();
            assert.equal(await page.locator('.bg-slate-900').first().evaluate(el => getComputedStyle(el).backgroundColor), 'rgb(15, 23, 42)');
        }
        await page.getByPlaceholder('GitHub Token', { exact: true }).fill('fake-token');
        await page.getByPlaceholder('owner/repo').fill('test/repo');
        await page.getByRole('button', { name: 'Connect Agent' }).click();
        await page.getByRole('heading', { name: 'The Merger 2.0' }).waitFor();
        await page.getByRole('button', { name: 'Compare', exact: true }).click();
        async function select(label, name) {
            const parent = page.locator('label').filter({ hasText: label }).locator('..');
            await parent.locator(':scope > div').first().click();
            await parent.getByText(name, { exact: true }).last().click();
        }
        await select('Target Branch', 'release');
        await select('Source Branch', 'feature');
        await page.getByRole('button', { name: 'Compare branch history' }).click();
        await page.getByRole('button', { name: 'Select These Commits' }).click();
        const row = i => page.locator(`[data-commit-sha="${commits[i].sha}"]`);
        await row(0).getByText('In base history', { exact: true }).waitFor();
        await row(1).getByText('Cherry-pick recorded in base', { exact: true }).waitFor();
        await row(2).getByText('Possible match in base', { exact: true }).waitFor();
        await row(3).getByText('ISCAR-9999 mentioned in base', { exact: true }).waitFor();
        await row(4).getByText('No history match', { exact: true }).waitFor();
        assert.match(await page.locator('body').innerText(), /104 base commits checked/);
        assert.equal(await row(1).getByRole('link', { name: 'View base commit' }).getAttribute('href'), 'https://github.com/test/repo/commit/' + 'd'.repeat(40));
        baseFailure = true;
        await page.getByRole('button', { name: 'Refresh base check' }).click();
        await row(0).getByText('Base check unavailable', { exact: true }).waitFor();
        assert.equal(await row(0).getByText('In base history', { exact: true }).count(), 0);
        baseFailure = false;
        await page.getByRole('button', { name: 'Refresh base check' }).click();
        await row(0).getByText('In base history', { exact: true }).waitFor();
        await page.getByPlaceholder('v29.x.x').fill('next');
        assert.equal(await page.getByLabel('Git committer name', { exact: true }).count(), 0);
        assert.equal(await page.getByLabel('Git committer email', { exact: true }).count(), 0);
        assert.match(await page.locator('body').innerText(), /Committer: Release User <release@example.com>/);
        await page.getByRole('button', { name: 'Prepare version' }).click();
        const publish = page.getByRole('button', { name: 'Publish branch next' });
        await publish.waitFor();
        assert.equal(preparePayload.name, 'Release User');
        assert.equal(preparePayload.email, 'release@example.com');
        assert.equal(preparePayload.source, 'feature');
        assert.equal(preparePayload.base, 'release');
        assert.equal(preparePayload.commits.length, 55, 'Must send every selected SHA, including selections outside initial 50');
        assert.equal(publishCount, 0, 'Preparation must never publish automatically');
        assert.match(await page.locator('section').innerText(), /selected change only/);
        await publish.click();
        await page.getByRole('link', { name: 'Open published branch' }).waitFor();
        assert.equal(publishCount, 1);
        mode = 'conflict';
        await page.getByRole('button', { name: 'Prepare version' }).click();
        await page.locator('section').getByText('Cherry-pick stopped. Nothing was pushed.', { exact: true }).waitFor();
        assert.equal(await publish.count(), 0, 'Conflicted jobs must have no Publish button');
        assert.match(await page.locator('section').innerText(), /Why Git stopped and how to resolve it/);
        assert.match(await page.locator('section').innerText(), /selected fix/);
        assert.equal(publishCount, 1, 'Conflict must not push');
        assert.match(await page.locator('section').innerText(), /shared.txt/);
        for (const identity of ['denied', 'jira', 'public', 'invalid', 'unavailable']) {
            await page.getByRole('button', { name: 'Sign Out' }).click();
            identityMode = identity;
            await page.getByPlaceholder('GitHub Token', { exact: true }).fill('other-token');
            await page.getByPlaceholder('owner/repo').fill('test/repo');
            const jiraEmail = identity === 'invalid' ? 'not-an-email' : identity === 'denied' ? '' : 'jira@example.com';
            await page.getByPlaceholder('email@example.com', { exact: true }).fill(jiraEmail);
            await page.getByRole('button', { name: 'Connect Agent' }).click();
            await page.getByRole('heading', { name: 'The Merger 2.0' }).waitFor();
            const manualEmail = ['denied', 'invalid'].includes(identity);
            assert.equal(await page.getByLabel('Git committer email', { exact: true }).count(), manualEmail ? 1 : 0);
            assert.equal(await page.getByLabel('Git committer name', { exact: true }).count(), identity === 'unavailable' ? 1 : 0);
            if (manualEmail) {
                assert.equal(await page.getByLabel('Git committer email', { exact: true }).inputValue(), '');
                await page.getByLabel('Git committer email', { exact: true }).fill('manual@example.com');
                assert.equal(await page.getByLabel('Git committer email', { exact: true }).inputValue(), 'manual@example.com');
            } else {
                const expectedEmail = identity === 'public' ? 'other@example.com' : 'jira@example.com';
                assert.match(await page.locator('body').innerText(), new RegExp(expectedEmail));
                if (identity === 'unavailable') await page.getByLabel('Git committer name', { exact: true }).fill('Manual Name');
                await select('2. Base Branch', 'release');
                await page.getByText('Selected task 1', { exact: true }).click();
                await page.getByRole('button', { name: 'Prepare version' }).click();
                await page.locator('section').getByText('Cherry-pick stopped. Nothing was pushed.', { exact: true }).waitFor();
                assert.equal(preparePayload.email, expectedEmail);
                assert.equal(preparePayload.name, identity === 'public' ? 'other-user' : identity === 'unavailable' ? 'Manual Name' : 'Release User');
            }
        }
        assert.deepEqual(errors, [], 'No browser runtime errors');
        if (process.env.MERGER_TEST_URL) assert.deepEqual(externalAssets, [], 'Packaged UI must not depend on CDN assets');
        console.log('PASS: 55 selected commits, chosen source, diff review, explicit publication, conflict blocks publication; GitHub identity autofill, private-email permissions, Jira fallback, GitHub precedence, invalid Jira email, missing profile, hidden identity fields and account switching; paginated base history, exact/cherry-pick/legacy/task badges, and failed refresh; no browser runtime errors.');
    } finally {
        if (browser) await browser.close();
        if (server) server.kill('SIGTERM');
    }
})().catch(error => { console.error(error); process.exitCode = 1; });
