"""Real Git integration tests; all repositories and pushes stay in temporary directories."""
import http.client
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import threading
import unittest
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
from merger_server import Job, make_server, validate, describe_conflicts


def git(path, *args):
    env = os.environ.copy()
    env.update(GIT_CONFIG_GLOBAL=os.devnull, GIT_CONFIG_NOSYSTEM='1')
    return subprocess.check_output(['git', '-C', str(path), *args], env=env, stderr=subprocess.PIPE).decode().strip()


class GitWorkflowTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.repo = self.root / 'source'
        self.repo.mkdir()
        git(self.repo, 'init', '-b', 'main')
        git(self.repo, 'config', 'user.name', 'Test Author')
        git(self.repo, 'config', 'user.email', 'test@example.com')
        self.original = [f'line {i}\n' for i in range(40)]
        (self.repo / 'shared.txt').write_text(''.join(self.original))
        (self.repo / 'delete.txt').write_text('remove me\n')
        (self.repo / 'rename.txt').write_text('rename me\n' * 10)
        (self.repo / 'script.sh').write_text('#!/bin/sh\necho ok\n')
        git(self.repo, 'add', '.')
        git(self.repo, 'commit', '-m', 'Initial')
        self.initial = git(self.repo, 'rev-parse', 'HEAD')
        git(self.repo, 'branch', 'release')
        self.remote = self.root / 'remote.git'
        git(self.root, 'init', '--bare', str(self.remote))
        git(self.repo, 'remote', 'add', 'origin', str(self.remote))

    def commit(self, message):
        git(self.repo, 'add', '-A')
        git(self.repo, 'commit', '-m', message)
        return git(self.repo, 'rev-parse', 'HEAD')

    def job(self, commits, **extra):
        git(self.repo, 'push', 'origin', '--all')
        data = dict(repo='test/repo', token='', base='release', source='main', branch='next',
                    name='Release User', email='release@example.com', commits=commits)
        data.update(extra)
        job = Job(data, self.root, remote=str(self.remote))
        job.prepare()
        return job

    def assertAbsent(self, branch='next'):
        self.assertEqual(git(self.repo, 'ls-remote', '--heads', 'origin', 'refs/heads/' + branch), '')

    def test_git_warning_is_not_mistaken_for_a_remote_ref(self):
        data = dict(repo='test/repo', token='secret', base='release', source='main', branch='next',
                    name='Test', email='test@example.com', commits=[self.initial])
        job = Job(data, self.root)
        response = subprocess.CompletedProcess([], 0, stdout='', stderr='warning: diagnostic secret\n')
        with patch('merger_server.subprocess.run', return_value=response):
            code, refs = job.git('ls-remote', '--heads', 'origin', 'refs/heads/next')
        self.assertEqual(code, 0)
        self.assertEqual(refs, '')
        self.assertEqual(job.snapshot()['logs'], ['warning: diagnostic [redacted]'])

    def test_only_selected_patch_preserves_release_fix_then_publishes(self):
        content = self.original.copy()
        content[0] = 'UNSELECTED feature\n'
        (self.repo / 'shared.txt').write_text(''.join(content))
        self.commit('Unselected change')
        content[20] = 'SELECTED fix\n'
        (self.repo / 'shared.txt').write_text(''.join(content))
        selected = self.commit('Selected fix')
        git(self.repo, 'switch', 'release')
        release = self.original.copy()
        release[39] = 'RELEASE hotfix\n'
        (self.repo / 'shared.txt').write_text(''.join(release))
        self.commit('Release-only fix')
        job = self.job([selected])
        self.assertEqual(job.snapshot()['state'], 'ready', job.snapshot())
        result = (job.path / 'shared.txt').read_text()
        self.assertNotIn('UNSELECTED', result)
        self.assertIn('SELECTED fix', result)
        self.assertIn('RELEASE hotfix', result)
        self.assertAbsent()
        self.assertEqual(git(job.path, 'show', '-s', '--format=%an'), 'Test Author')
        self.assertEqual(git(job.path, 'show', '-s', '--format=%cn'), 'Release User')
        job.start_publish('')
        job.publish()
        self.assertEqual(job.snapshot()['state'], 'published', job.snapshot())
        self.assertEqual(git(self.remote, 'rev-parse', 'refs/heads/next'), job.snapshot()['head'])
        self.assertEqual(git(job.path, 'config', 'branch.next.remote'), 'origin')
        self.assertEqual(git(job.path, 'config', 'branch.next.merge'), 'refs/heads/next')
        with self.assertRaises(ValueError):
            job.start_publish('')

    def test_deletion_rename_binary_symlink_and_executable_preserved(self):
        (self.repo / 'delete.txt').unlink()
        (self.repo / 'rename.txt').rename(self.repo / 'renamed.txt')
        (self.repo / 'script.sh').chmod(0o755)
        (self.repo / 'link').symlink_to('renamed.txt')
        (self.repo / 'binary.bin').write_bytes(bytes(range(256)))
        selected = self.commit('File operations')
        job = self.job([selected])
        self.assertEqual(job.snapshot()['state'], 'ready', job.snapshot())
        self.assertFalse((job.path / 'delete.txt').exists())
        self.assertFalse((job.path / 'rename.txt').exists())
        self.assertTrue((job.path / 'renamed.txt').exists())
        self.assertTrue((job.path / 'link').is_symlink())
        self.assertEqual((job.path / 'binary.bin').read_bytes(), bytes(range(256)))
        self.assertTrue(os.access(job.path / 'script.sh', os.X_OK))

    def test_conflict_stops_remaining_commits_and_blocks_publish(self):
        (self.repo / 'shared.txt').write_text('source\n')
        conflict = self.commit('Conflicting commit')
        (self.repo / 'later.txt').write_text('must not apply\n')
        later = self.commit('Later commit')
        git(self.repo, 'switch', 'release')
        (self.repo / 'shared.txt').write_text('release\n')
        self.commit('Release divergence')
        job = self.job([later, conflict])
        self.assertEqual(job.snapshot()['state'], 'conflict', job.snapshot())
        self.assertEqual(job.snapshot()['current_commit'], conflict)
        self.assertEqual(job.snapshot()['conflicts'], ['shared.txt'])
        self.assertFalse((job.path / 'later.txt').exists())
        before = git(job.path, 'status', '--porcelain')
        report = describe_conflicts(job.path)
        self.assertEqual(report['commit'], conflict)
        self.assertEqual(report['files'][0]['versions']['release']['text'], 'release\n')
        self.assertEqual(report['files'][0]['versions']['incoming']['text'], 'source\n')
        self.assertIn('<<<<<<<', report['files'][0]['conflict_diff'])
        self.assertIn('+source', report['files'][0]['patch'])
        self.assertEqual(git(job.path, 'status', '--porcelain'), before)
        self.assertEqual(job.snapshot()['conflict_report'], report)
        with self.assertRaises(ValueError):
            job.start_publish('')
        self.assertAbsent()

    def test_conflict_advice_for_missing_source_feature(self):
        (self.repo / 'feature.txt').write_text('feature version one\n')
        earlier = self.commit('Unselected prerequisite feature')
        (self.repo / 'feature.txt').write_text('feature version two\n')
        selected = self.commit('Modify missing feature')
        job = self.job([selected])
        self.assertEqual(job.snapshot()['state'], 'conflict')
        file = job.snapshot()['conflict_report']['files'][0]
        self.assertEqual(file['kind'], 'Release deletion versus incoming changes')
        self.assertIsNone(file['versions']['release']['mode'])
        self.assertIn('Unselected prerequisite feature', file['history'])
        self.assertIn('+feature version two', file['patch'])
        self.assertAbsent()

    def test_binary_conflict_advice(self):
        (self.repo / 'binary.bin').write_bytes(b'base\0data')
        initial = self.commit('Binary base')
        git(self.repo, 'branch', '-f', 'release', initial)
        (self.repo / 'binary.bin').write_bytes(b'source\0data')
        selected = self.commit('Source binary')
        git(self.repo, 'switch', 'release')
        (self.repo / 'binary.bin').write_bytes(b'release\0data')
        self.commit('Release binary')
        job = self.job([selected])
        self.assertEqual(job.snapshot()['state'], 'conflict')
        file = job.snapshot()['conflict_report']['files'][0]
        self.assertIn('Binary contents', file['explanation'])
        self.assertIn('Binary contents', file['versions']['release']['text'])
        self.assertAbsent()

    def test_ancestry_order_not_selection_order(self):
        (self.repo / 'chain.txt').write_text('one\n')
        first = self.commit('First')
        (self.repo / 'chain.txt').write_text('two\n')
        second = self.commit('Second')
        job = self.job([second, first])
        self.assertEqual(job.snapshot()['state'], 'ready', job.snapshot())
        self.assertEqual(job.snapshot()['ordered'], [first, second])
        self.assertEqual((job.path / 'chain.txt').read_text(), 'two\n')

    def test_missing_selection_is_error(self):
        job = self.job(['f' * 40])
        self.assertEqual(job.snapshot()['state'], 'error')
        self.assertIn('not reachable', job.snapshot()['error'])
        self.assertAbsent()

    def test_existing_branch_never_overwritten(self):
        git(self.repo, 'branch', 'next')
        job = self.job([self.initial])
        self.assertEqual(job.snapshot()['state'], 'error')
        self.assertIn('already exists', job.snapshot()['error'])
        self.assertEqual(git(self.remote, 'rev-parse', 'refs/heads/next'), self.initial)

    def test_merge_commit_rejected_before_picking(self):
        git(self.repo, 'switch', '-c', 'feature')
        (self.repo / 'feature.txt').write_text('feature\n')
        self.commit('Feature')
        git(self.repo, 'switch', 'main')
        (self.repo / 'main.txt').write_text('main\n')
        self.commit('Main')
        git(self.repo, 'merge', '--no-ff', 'feature', '-m', 'Merge')
        merge = git(self.repo, 'rev-parse', 'HEAD')
        job = self.job([merge])
        self.assertEqual(job.snapshot()['state'], 'error')
        self.assertIn('merge commit', job.snapshot()['error'])
        self.assertAbsent()

    def test_empty_pick_stops(self):
        (self.repo / 'new.txt').write_text('same\n')
        pick = self.commit('Already applied')
        git(self.repo, 'branch', '-f', 'release', pick)
        job = self.job([pick])
        self.assertEqual(job.snapshot()['state'], 'error')
        self.assertIn('empty/already applied', job.snapshot()['error'])
        self.assertAbsent()

    def test_publish_rejection_is_error(self):
        (self.repo / 'new.txt').write_text('change\n')
        job = self.job([self.commit('Change')])
        hook = self.remote / 'hooks' / 'pre-receive'
        hook.write_text('#!/bin/sh\necho rejected >&2\nexit 1\n')
        hook.chmod(0o755)
        job.start_publish('')
        job.publish()
        self.assertEqual(job.snapshot()['state'], 'error')
        self.assertIn('rejected', job.snapshot()['error'])
        self.assertAbsent()

    def test_branch_created_during_push_is_not_overwritten(self):
        (self.repo / 'new.txt').write_text('change\n')
        job = self.job([self.commit('Change')])
        original_git = job.git
        def race(*args, **kwargs):
            if args[0] == 'push':
                git(self.remote, 'update-ref', 'refs/heads/next', self.initial)
            return original_git(*args, **kwargs)
        job.git = race
        job.start_publish('')
        job.publish()
        self.assertEqual(job.snapshot()['state'], 'error')
        self.assertEqual(git(self.remote, 'rev-parse', 'refs/heads/next'), self.initial)

    def test_changed_checkout_cannot_publish(self):
        (self.repo / 'new.txt').write_text('change\n')
        job = self.job([self.commit('Change')])
        (job.path / 'shared.txt').write_text('unreviewed\n')
        job.start_publish('')
        job.publish()
        self.assertEqual(job.snapshot()['state'], 'error')
        self.assertIn('checkout changed', job.snapshot()['error'])
        self.assertAbsent()


class HttpTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.server = make_server(0, self.temp.name)
        self.thread = threading.Thread(target=self.server.serve_forever, daemon=True)
        self.thread.start()

    def tearDown(self):
        self.server.shutdown()
        self.server.server_close()
        self.thread.join()
        self.temp.cleanup()

    def request(self, method, path, data=None, headers=None):
        conn = http.client.HTTPConnection('127.0.0.1', self.server.server_port)
        conn.request(method, path, body=json.dumps(data) if data is not None else None, headers=headers or {})
        response = conn.getresponse()
        result = response.status, response.read().decode(), dict(response.getheaders())
        conn.close()
        return result

    def test_session_and_csrf_and_html(self):
        self.assertEqual(self.request('GET', '/merger.html')[0], 401)
        status, _, headers = self.request('GET', '/?session=' + self.server.secret)
        self.assertEqual(status, 303)
        cookie = headers['Set-Cookie'].split(';')[0]
        status, html, _ = self.request('GET', '/merger.html', headers={'Cookie': cookie})
        self.assertEqual(status, 200)
        self.assertIn('window.MERGER_SESSION=', html)
        self.assertEqual(self.request('POST', '/api/merger/jobs', {}, {'Cookie': cookie})[0], 403)
        valid = {'Cookie': cookie, 'X-Merger-Session': self.server.secret}
        self.assertEqual(self.request('POST', '/api/merger/jobs', {}, valid)[0], 400)
        cross = dict(valid, Origin='https://example.com')
        self.assertEqual(self.request('POST', '/api/merger/jobs', {}, cross)[0], 403)
        self.assertEqual(self.request('POST', '/api/merger/jira', {'job': 'nope'}, valid)[0], 400)

    def test_validation(self):
        data = dict(repo='owner/repo', base='release', source='main', branch='next',
                    name='User', email='user@example.com', token='secret', commits=['a' * 40])
        validate(data)
        for update in ({'repo': '../bad'}, {'branch': 'release'}, {'branch': '--help'},
                       {'commits': []}, {'commits': ['HEAD']}, {'token': 'bad\nvalue'}):
            with self.subTest(update=update), self.assertRaises(ValueError):
                validate(dict(data, **update))


if __name__ == '__main__':
    unittest.main()
